module.exports = {
    mount: {
        'public': '/',
        'src': '/dist'
    }
}