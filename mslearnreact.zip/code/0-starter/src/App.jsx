import './index.css'
import React, { useEffect } from 'react';
import RecipeTitle from './RecipeTitle'


function App() {
    
    useEffect(() => {
        console.log("testting env", import.meta.env.REACT_APP_BASEAPI_URL);
    }, [])
    return (
        <article>
            <h1>Recipe Manager</h1>
            <RecipeTitle />
        </article>
    )
}

export default App;