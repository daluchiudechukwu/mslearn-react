import './index.css'
import React from 'react';
// TODO: Import RecipeTitle

// TODO: Import IngredientList


function App() {
    // TODO: Add recipe object

    return (
        <article>
            <h1>Recipe Manager</h1>
            {/* TODO: Add RecipeTitle component */}

            {/* TODO: Add IngredientList component */}

        </article>
    )
}

export default App;
