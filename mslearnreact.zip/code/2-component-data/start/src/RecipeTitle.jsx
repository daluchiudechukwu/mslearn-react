import React from 'react';

// TODO: Create RecipeTitle component
