export const MODE = "production";
export const NODE_ENV = "production";
export const SSR = false;